
function [outputSignal, noiseSignal] = communicationSystem(channel, fs, noise, impulse_Filter)
    % Initialization
    t = (0:length(channel)-1) / fs;
    y = channel;
    t_conv = t;

    % filter design

    if (impulse_Filter ==1) % ideal impusle filter 
 
        H1 = [1 zeros(1,length(channel)-1)];
        H1 = H1(1:length(channel)); 
        y = conv(channel(:,1), H1, 'same'); 
        t_conv = (0:length(y)-1) / fs;

    elseif (impulse_Filter == 2)
        % Generate exponential filter
        H2 = exp(-2*pi*2000*t);
        H2 = H2(1:length(channel)); 
        y = conv(channel(:,1), H2, 'valid'); 
        t_conv = (0:length(y)-1) / fs; % Adjusting time vector for output
  
    elseif (impulse_Filter ==3)
         
        H3 = exp(-2*pi*500*t);
        H3 = H3(1:length(channel)); 
        y = conv(channel(:,1), H3, 'valid'); 
        t_conv = (0:length(y)-1) / fs; 
    else
        fprintf('select a valid Filter.')
    return
    end

    % Adding noise to the signal
    noiseSignal = y + noise * randn(size(channel));

    outputSignal = channel; %  output
end

