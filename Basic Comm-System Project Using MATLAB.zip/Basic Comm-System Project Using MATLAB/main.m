
% Load an audio file
file_path = 'dawn of faith.mpeg';  
[inputAudio, fs] = audioread(file_path);
 sound(inputAudio,fs);
pause(25);

% Parameters for communicationSystem function
rnd=rand(1000,1);
noise = rnd(5);
impulse_Filter=input('select type of filter(1-3)= ');

% Call the communicationSystem function
[outputSignal, noiseSignal] = communicationSystem(inputAudio, fs, noise, impulse_Filter);
sound(noiseSignal,fs);
pause(25)

% 
sound(outputSignal,fs);
pause(25)
% Plotting the original audio, noisy audio, and output audio
t = (0:length(inputAudio)-1) / fs;
figure;

subplot(3,1,1);
plot(t, inputAudio);
title('Original Audio signal');
xlabel('Time');
ylabel('Amplitude');

subplot(3,1,2);
plot(t, noiseSignal);
title('audio singal affected by the niose');
xlabel('Time');
ylabel('Amplitude');

subplot(3,1,3);
plot(t, outputSignal);
title('Reconstructed audio signal');
xlabel('Time');
ylabel('Amplitude');

